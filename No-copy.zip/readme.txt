=== No copy block text selection ===
Contributors: (cjperes)
Tags: block,copy,ctrlc,ctrlv,disable
Requires at least: 4.6
Tested up to: 4.7
Stable tag: 4.3
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Simple plugin for turning off copies on a website

== Description ==

Simple plugin for turning off copies on a website

Light and simple
This plugin uses javascript to disable the copy, if the user disables the browser javascript, this plugin will not work!

Works perfectly with all themes and editors of Wordpress

The plugin is licensed to you "as is" and without any warranty. If you do not agree to the license, do not use.



== Installation ==


1. Upload the plugin files to the `/wp-content/plugins/no-copy-block-selection` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Done

